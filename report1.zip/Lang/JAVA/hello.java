class test {
	public static void main(String args[]) {
		System.out.println("Hello JAVA world\n");
	}
}
