#include <stdio.h>
#include <string.h>

#define MAXLINE 100

char line[MAXLINE];
char longest[MAXLINE];

void copy();
char *mygets();
