#include <stdio.h>

int main() 
{
	char ch1, ch2;

	printf("대문자 입력 : ");
	scanf("%c", &ch1);
	getchar();
	printf("소문자 입력 : ");
	scanf("%c", &ch2);

	printf("입력한 %c의 소문자는 %c입니다.\n", ch1, ch1 + 32);
	printf("입력한 %c의 대문자는 %c입니다.\n", ch2, ch2 - 32);

	return 0;
}
